import Phaser from 'phaser';

import BasePlayerScene from './BasePlayerScene';

import {
  EPISODE2_DIALOGUE,
  buildEpisode2CounselingContext,
} from '../dialogue/episode2Dialogue';

import DialogueBox from '../ui/DialogueBox';
import ObjectiveBriefing from '../ui/ObjectiveBriefing';

import { getCharacterName } from '../utils/characterName';
import { getEpisodeById } from '../config/episodes';
import { pxToWorld } from '../utils/visibleBounds';

// ================================================================
// EPISODE 2 — RAHASIA DI GRUP KELAS
// ================================================================
//
// Background asli:
// 1672 x 941 px
//
// Scene Phaser:
// sekitar 1280 x 720
//
// Karena aspect ratio keduanya hampir sama, posisi dari gambar
// referensi dapat dikonversi dengan sangat stabil.
//
// ================================================================

// ================================================================
// KOORDINAT BERDASARKAN BACKGROUND ASLI 1672 x 941
// ================================================================
//
// Jangan isi posisi langsung dengan koordinat dunia Phaser.
// Kita simpan koordinat berdasarkan GAMBAR ASLI supaya kalau ukuran
// rendering berubah, posisinya masih tetap sinkron.
//
// ================================================================

// Garis kaki karakter pada background asli.
//
// Dari background kamar, lantai tempat karakter berdiri kira-kira
// berada pada Y = 785.
//
// Ketika gambar 941px diskalakan ke tinggi 720:
//
// 785 / 941 * 720 ≈ 601
//
// Sangat dekat dengan ground Episode 1 = 600.
//
const GROUND_REF_Y = 785;

// Posisi awal Sekar.
//
// Dibuat dekat pintu kanan, seolah baru masuk kamar.
const PLAYER_START_REF_X = 1430;

// Batas horizontal karakter.
//
// Supaya pemain tidak masuk terlalu jauh ke area kasur kiri
// atau melewati pintu kanan.
const WALK_MIN_REF_X = 285;
const WALK_MAX_REF_X = 1500;

// ================================================================
// POSISI HP
// ================================================================
//
// HP diletakkan di atas meja.
//
// Background belum memiliki HP yang sangat terlihat,
// jadi untuk sementara kita menggambar placeholder HP kecil
// menggunakan Phaser.
//
// Nanti kalau sudah punya asset:
//
// public/objects/phone.png
//
// placeholder ini tinggal diganti sprite.
//
const PHONE_REF_X = 990;
const PHONE_REF_Y = 545;

// Seberapa dekat pemain harus berada secara horizontal
// sebelum prompt interaksi muncul.
const PHONE_INTERACTION_RADIUS = 115;

// ================================================================
// SCENE
// ================================================================

export default class Episode2Scene extends BasePlayerScene {
  constructor() {
    super('Episode2Scene');
  }

  // ==============================================================
  // INIT
  // ==============================================================

  init(data) {
    super.init(data);

    // Episode ini harus selalu dianggap Episode 2.
    this.episodeId = 2;

    this.finished = false;

    this.phoneInDialogue = false;
    this.phoneQuestComplete = false;

    this.phoneChoices = [];

    this._phoneInteractCooldownUntil = 0;
  }

  // ==============================================================
  // CREATE
  // ==============================================================

  create(data) {
    // Semua sistem dasar:
    //
    // - player
    // - physics
    // - kamera
    // - HUD
    // - movement
    // - touch controls
    // - chatbot button
    //
    // tetap memakai BasePlayerScene.
    super.create(data);

    // ============================================================
    // POSISI AWAL PLAYER
    // ============================================================
    //
    // Kalau ini bukan restart akibat perubahan orientasi,
    // tempatkan Sekar dekat pintu kanan.
    //
    if (!data?.preservePlayer && this.player) {
      const startX = this._bgLeft + PLAYER_START_REF_X * this._backgroundScale;

      this.player.x = Phaser.Math.Clamp(startX, this.walkMinX, this.walkMaxX);

      // Menghadap kiri / ke arah isi kamar.
      this.player.setFlipX(true);
    }

    // ============================================================
    // CHATBOT KAK DARA
    // ============================================================
    //
    // Sama seperti Episode 1:
    // chatbot disembunyikan dulu.
    //
    // Baru ditampilkan setelah quest HP selesai.
    //
    this.setChatButtonVisible(false);

    // ============================================================
    // QUEST GUIDE
    // ============================================================

    this.setQuestGuide('○ ── Periksa HP di meja ──');

    // ============================================================
    // OBJECTIVE BRIEFING
    // ============================================================

    this.uiInputLocked = true;

    this.player?.setVelocity(0, 0);
    this.player?.anims.stop();

    const episodeData = getEpisodeById(2);

    this.objectiveBriefing = new ObjectiveBriefing(this);

    this.objectiveBriefing.show({
      title: 'TUJUAN EPISODE',

      objectiveText:
        episodeData?.objective ??
        'Periksa ponsel di meja dan perhatikan percakapan ' +
          'di grup kelas. Tentukan bagaimana kamu akan ' +
          'merespons ketika melihat teman mengalami cyberbullying.',

      onContinue: () => {
        this.uiInputLocked = false;
      },
    });
  }

  // ==============================================================
  // BACKGROUND
  // ==============================================================

  createBackground(width, height) {
    this.finished = false;

    // ============================================================
    // FALLBACK
    // ============================================================
    //
    // Kalau gambar belum berhasil dimuat, game tetap bisa dijalankan.
    //
    if (!this.textures.exists('episode2-bg')) {
      this.levelWidth = width;

      this.add
        .rectangle(width / 2, height / 2, width, height, 0x5b4a55)
        .setDepth(0);

      this.groundY = height - 120;

      this._backgroundScale = 1;
      this._bgLeft = 0;

      this.walkMinX = 180;
      this.walkMaxX = width - 180;

      this.phoneX = width * 0.62;

      this.phoneY = height * 0.58;

      this._createPhoneObject();

      return;
    }

    // ============================================================
    // BACKGROUND ASLI
    // ============================================================

    const source = this.textures.get('episode2-bg').getSourceImage();

    // Scale berdasarkan tinggi.
    //
    // Tidak ada stretching / distorsi.
    const scale = height / source.height;

    this._backgroundScale = scale;

    // Lebar natural setelah gambar diskalakan.
    const naturalWidth = Math.round(source.width * scale);

    // Minimal selebar viewport dunia.
    this.levelWidth = Math.max(naturalWidth, width);

    // ============================================================
    // BACKGROUND FILL
    // ============================================================
    //
    // Kalau layar super lebar, jangan TILE kamar karena hasilnya
    // terlihat seperti ada dua kamar berulang.
    //
    // Lebih baik beri warna gelap di belakang gambar.
    //
    this.backgroundFill = this.add
      .rectangle(
        this.levelWidth / 2,
        height / 2,
        this.levelWidth,
        height,
        0x5a4b52,
      )
      .setDepth(-1);

    // Background kamar diletakkan di tengah.
    this._bgLeft = (this.levelWidth - naturalWidth) / 2;

    this.bg = this.add.image(
      this._bgLeft + naturalWidth / 2,

      height / 2,

      'episode2-bg',
    );

    this.bg.setDisplaySize(naturalWidth, height);

    this.bg.setDepth(0);

    // ============================================================
    // GROUND
    // ============================================================
    //
    // Ground dihitung LANGSUNG dari background.
    //
    // Jadi kaki karakter akan selalu berada pada titik yang sama
    // terhadap lantai kamar.
    //
    this.groundY = Math.round(GROUND_REF_Y * scale);

    // ============================================================
    // WALKABLE AREA
    // ============================================================

    this.walkMinX = this._bgLeft + WALK_MIN_REF_X * scale;

    this.walkMaxX = this._bgLeft + WALK_MAX_REF_X * scale;

    // ============================================================
    // PHONE POSITION
    // ============================================================

    this.phoneX = this._bgLeft + PHONE_REF_X * scale;

    this.phoneY = PHONE_REF_Y * scale;

    // Buat objek HP setelah koordinat final diketahui.
    this._createPhoneObject();
  }

  // ==============================================================
  // CREATE PHONE
  // ==============================================================

  _createPhoneObject() {
    const scene = this;

    // ============================================================
    // PHONE BODY
    // ============================================================
    //
    // Placeholder kecil untuk HP yang tergeletak di meja.
    //
    // Dibuat horizontal supaya terlihat sedang diletakkan di meja.
    //
    this.phoneBody = scene.add
      .rectangle(this.phoneX, this.phoneY, 31, 13, 0x171a22, 1)
      .setStrokeStyle(2, 0x596273, 1)
      .setDepth(0.8)
      .setAngle(-4);

    // Sedikit layar / highlight HP.
    this.phoneScreen = scene.add
      .rectangle(this.phoneX, this.phoneY, 23, 7, 0x35445c, 1)
      .setDepth(0.81)
      .setAngle(-4);

    // ============================================================
    // INTERACTIVE HIT AREA
    // ============================================================
    //
    // Area klik dibuat lebih besar daripada ukuran visual HP,
    // supaya mudah disentuh di mobile.
    //
    this.phoneHitArea = scene.add
      .rectangle(this.phoneX, this.phoneY, 72, 60, 0xffffff, 0.001)
      .setDepth(1.5)
      .setInteractive({
        useHandCursor: true,
      });

    this.phoneHitArea.on('pointerdown', () => {
      this._tryOpenPhone();
    });

    // ============================================================
    // PROMPT INTERAKSI
    // ============================================================

    const promptFont = pxToWorld(this, 15);

    this.phonePrompt = this.add
      .text(
        this.phoneX,
        this.phoneY - 42,

        '[E] Buka HP (Klik)',

        {
          fontFamily: '"Pixelify Sans", monospace',

          fontSize: `${promptFont}px`,

          color: '#ffffff',

          backgroundColor: '#1a1a2e',

          padding: {
            x: 9,
            y: 5,
          },
        },
      )
      .setOrigin(0.5, 1)
      .setDepth(3)
      .setVisible(false)
      .setInteractive({
        useHandCursor: true,
      });

    this.phonePrompt.on('pointerdown', () => {
      this._tryOpenPhone();
    });

    // ============================================================
    // INTERACTION KEY
    // ============================================================

    this.interactKey = this.input.keyboard.addKey(
      Phaser.Input.Keyboard.KeyCodes.E,
    );

    // Supaya ikut mati ketika ada overlay React.
    this.registerLockable(this.phoneHitArea);

    this.registerLockable(this.phonePrompt);

    // DialogueBox digunakan seperti Episode 1.
    this.dialogueBox = new DialogueBox(this);
  }

  // ==============================================================
  // OPEN PHONE QUEST
  // ==============================================================

  _tryOpenPhone() {
    if (this.phoneInDialogue || this.phoneQuestComplete) {
      return;
    }

    // Jangan bisa dibuka ketika objective briefing,
    // pause menu, atau overlay lain masih aktif.
    if (this.uiInputLocked) {
      return;
    }

    // Pemain harus berada dekat meja.
    if (!this.phonePrompt?.visible) {
      return;
    }

    // Cooldown dari interaksi sebelumnya.
    if (this.time.now < this._phoneInteractCooldownUntil) {
      return;
    }

    this._startPhoneDialogue();
  }

  // ==============================================================
  // START EPISODE 2 DIALOGUE
  // ==============================================================

  _startPhoneDialogue() {
    if (this.phoneInDialogue) {
      return;
    }

    this.phoneInDialogue = true;

    this.phonePrompt?.setVisible(false);

    // Kunci movement player.
    this.uiInputLocked = true;

    this.player?.setVelocity(0, 0);

    this.player?.anims.stop();

    // ============================================================
    // OPEN DIALOGUE
    // ============================================================

    this.dialogueBox.open({
      dialogueTree: EPISODE2_DIALOGUE,

      // Untuk sekarang DialogueBox belum benar-benar memakai
      // portrait secara visual, tetapi key tetap diberikan agar
      // kompatibel jika nanti portrait diaktifkan.
      npcPortraitKey: 'npc-rafi-portrait',

      npcName: 'Rafi',

      playerName: getCharacterName(),

      // ==========================================================
      // QUEST FINISHED
      // ==========================================================

      onClose: async (collectedChoices) => {
        this.phoneChoices = collectedChoices;

        this.phoneQuestComplete = true;

        // Quest guide selesai.
        this.clearQuestGuide();

        // Chatbot Kak Dara boleh diakses.
        this.setChatButtonVisible(true);

        // ======================================================
        // OFFER COUNSELING
        // ======================================================
        //
        // Seperti Episode 1:
        // pilihan-pilihan pemain dirangkum menjadi konteks otomatis.
        //
        const ui = window.__nawasenadaraUI;

        if (ui?.offerCounseling) {
          await ui.offerCounseling({
            episodeId: 2,

            npcName: 'Rafi',

            autoContext: this.getCounselingAutoContext(),
          });
        }

        // Scene mungkin sudah dihentikan oleh proses lain.
        if (!this.scene.isActive()) {
          return;
        }

        this.phoneInDialogue = false;

        this._phoneInteractCooldownUntil = this.time.now + 400;

        // Setelah seluruh dialog selesai,
        // langsung masuk ke ending episode.
        this._finishEpisode2();
      },
    });
  }

  // ==============================================================
  // COUNSELING CONTEXT
  // ==============================================================

  getCounselingAutoContext() {
    return buildEpisode2CounselingContext(this.phoneChoices);
  }

  // ==============================================================
  // END EPISODE
  // ==============================================================

  _finishEpisode2() {
    if (this.finished) {
      return;
    }

    this.finished = true;

    this.uiInputLocked = true;

    this.phonePrompt?.setVisible(false);

    this.player?.setVelocity(0, 0);

    this.player?.anims.stop();

    const choices = this.phoneChoices || [];

    // Sedikit fade player supaya transisi lebih lembut.
    if (this.player) {
      this.tweens.add({
        targets: this.player,

        alpha: 0,

        duration: 300,

        ease: 'Sine.easeOut',

        onComplete: () => {
          this.scene.start('EpisodeEndingScene', {
            episodeId: 2,

            isLastEpisode: false,

            choices,
          });
        },
      });

      return;
    }

    // Fallback kalau player entah kenapa tidak ada.
    this.scene.start('EpisodeEndingScene', {
      episodeId: 2,

      isLastEpisode: false,

      choices,
    });
  }

  // ==============================================================
  // PER-FRAME UPDATE
  // ==============================================================

  onSceneUpdate() {
    if (!this.player || this.finished) {
      return;
    }

    // ============================================================
    // BATASI AREA BERJALAN
    // ============================================================
    //
    // BasePlayerScene memang sudah memakai physics world bounds,
    // tapi kamar punya batas jalan lebih kecil dari ukuran background.
    //
    this.player.x = Phaser.Math.Clamp(
      this.player.x,
      this.walkMinX,
      this.walkMaxX,
    );

    // ============================================================
    // JANGAN CEK INTERACTION SAAT DIALOG
    // ============================================================

    if (this.phoneInDialogue || this.phoneQuestComplete) {
      this.phonePrompt?.setVisible(false);

      return;
    }

    // ============================================================
    // PROXIMITY KE HP
    // ============================================================
    //
    // Karena gameplay side-scrolling hanya memakai sumbu X
    // untuk navigasi horizontal, jarak cukup dihitung dari X.
    //
    const distance = Math.abs(this.player.x - this.phoneX);

    const inRange = distance <= PHONE_INTERACTION_RADIUS;

    this.phonePrompt?.setVisible(inRange);

    // ============================================================
    // KEYBOARD E
    // ============================================================

    if (inRange && Phaser.Input.Keyboard.JustDown(this.interactKey)) {
      this._tryOpenPhone();
    }
  }
}
