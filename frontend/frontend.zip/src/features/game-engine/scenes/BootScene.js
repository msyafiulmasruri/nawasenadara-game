import Phaser from 'phaser';
import { createPlayerAnimations } from '../config/playerAnimations';
import { EPISODES } from '../config/episodes';
import { NPCS } from '../config/npcs';

export default class BootScene extends Phaser.Scene {
  constructor() {
    super('BootScene');
  }

  preload() {
    // --- Loading bar ---
    // Sebelumnya scene ini tidak menggambar apa-apa selama preload()
    // berjalan — canvas cuma hitam polos sampai semua aset (background
    // tiap episode, sprite pemain, dll.) selesai dimuat. Di koneksi
    // lambat ini terasa seperti "macet"/tidak merespons. Sekarang
    // ditambah UI loading sederhana: judul + bar progres + persentase,
    // di-update lewat event 'progress' bawaan Phaser Loader, dan
    // dibersihkan otomatis di 'complete'.
    const { width, height } = this.scale;
    const barWidth = Math.min(width * 0.6, 360);
    const barHeight = 14;
    const barX = width / 2 - barWidth / 2;
    const barY = height / 2;

    this.add.rectangle(width / 2, height / 2, width, height, 0x05050f).setDepth(0);

    const loadingText = this.add
      .text(width / 2, barY - 40, 'NAWASENA DARA', {
        fontFamily: 'monospace', // font pixel custom belum tentu siap dimuat browser di titik ini
        fontSize: '20px',
        color: '#ffdd57',
        align: 'center',
      })
      .setOrigin(0.5)
      .setDepth(1);

    const percentText = this.add
      .text(width / 2, barY + barHeight + 18, '0%', {
        fontFamily: 'monospace',
        fontSize: '14px',
        color: '#ffffff',
      })
      .setOrigin(0.5)
      .setDepth(1);

    const barBg = this.add
      .rectangle(width / 2, barY, barWidth, barHeight, 0x1a1a2e)
      .setStrokeStyle(2, 0x3a3a44)
      .setDepth(1);

    const barFill = this.add
      .rectangle(barX, barY, 1, barHeight - 4, 0xffdd57)
      .setOrigin(0, 0.5)
      .setDepth(1);

    this.load.on('progress', (value) => {
      barFill.width = Math.max(1, (barWidth - 4) * value);
      percentText.setText(`${Math.round(value * 100)}%`);
    });

    this.load.on('complete', () => {
      loadingText.destroy();
      percentText.destroy();
      barBg.destroy();
      barFill.destroy();
    });


    // Catatan: title-logo.png belum ada di aset proyek. TitleScene sudah
    // punya fallback teks pixel kalau texture ini tidak ditemukan, jadi
    // baris load-nya sengaja tidak diaktifkan sampai asetnya tersedia.
    // Kalau logo sudah siap, taruh filenya di public/ui/title-logo.png lalu
    // aktifkan lagi baris di bawah ini:
    // this.load.image('title-logo', '/ui/title-logo.png');

    this.load.image('press-start-bg', '/ui/press-start-bg.png');

    // --- Background semua episode, di-load dari satu sumber data ---
    // (config/episodes.js) supaya menambah episode baru tidak perlu
    // sentuh file ini lagi sama sekali.
    //
    // PENTING: file yang belum ada (misalnya latar final Episode 6)
    // TIDAK menggagalkan proses loading keseluruhan. Phaser's Loader
    // menembakkan event 'loaderror' PER FILE yang gagal lalu tetap
    // lanjut memuat sisanya — makanya aman untuk selalu mencoba
    // me-load SEMUA path di bawah dari sekarang, walau sebagian besar
    // filenya belum ada. Scene episode lalu mengecek
    // `this.textures.exists(bgKey)` saat runtime: kalau berhasil
    // dimuat (artinya file sudah ditaruh di public/scenes/), otomatis
    // dipakai sebagai background asli dengan logika portrait/landscape
    // yang sama persis seperti Episode1Scene; kalau belum ada, otomatis
    // fallback ke visual terarah seperti sekarang. Jadi menambah art
    // episode baru nanti benar-benar cuma "taruh file, selesai" — tidak
    // perlu sentuh BootScene sama sekali.
    this.load.on('loaderror', (file) => {
      // Diam-diam saja di console (bukan error UI) — ini kondisi yang
      // DIHARAPKAN terjadi untuk episode yang art-nya belum ada.
      console.info(`[BootScene] Aset opsional belum tersedia: ${file.key} (${file.src})`);
    });

    EPISODES.forEach((ep) => {
      if (ep.bgKey && ep.bgImagePath) {
        this.load.image(ep.bgKey, ep.bgImagePath);
      }
      // Aset opsional tambahan per episode (mis. overlay layar HP ep3)
      if (ep.hpOverlayKey && ep.hpOverlayPath) {
        this.load.image(ep.hpOverlayKey, ep.hpOverlayPath);
      }
    });

    // Aset cutscene bercabang Episode 1
    this.load.image('ep1-corridor-choice-a', '/scenes/ep1-corridor-choice-a.jpg');
    this.load.image('ep1-corridor-choice-b', '/scenes/ep1-corridor-choice-b.jpg');
    this.load.image('ep1-corridor-choice-c', '/scenes/ep1-corridor-choice-c.jpg');

    // Aset khusus Episode 2: cutscene cabang B/C dan background kelas Kirana
    this.load.image('ep2-hp-grup-diam', '/scenes/ep2-hp-grup-diam.jpg');
    this.load.image('ep2-koridor-sekolah-hp', '/scenes/ep2-koridor-sekolah-hp.jpg');

    this.load.image('ep2-hp-grup-ketawa', '/scenes/ep2-hp-grup-ketawa.jpg');
    this.load.image('ep2-kelas-closeup-kirana', '/scenes/ep2-kelas-closeup-kirana.jpg');

    this.load.image('ep2-kelas-kirana-sendirian', '/scenes/ep2-kelas-kirana-sendirian.jpg');
    this.load.image('ep2-kelas-kirana-ditertawakan', '/scenes/ep2-kelas-kirana-ditertawakan.jpg');

    this.load.image('phone-ep3', '/sprites/phone-ep3.png');
    this.load.image('phone-ep3-pov', '/scenes/ep3-phone-pov.png');
    this.load.image('ep3-window-cg', '/scenes/ep3-window-cg.jpg');

    // Aset cutscene bercabang Episode 4 — area kantin sekolah
    this.load.image('ep4-canteen-choice-a', '/scenes/ep4-canteen-choice-a.jpg');
    this.load.image('ep4-canteen-choice-b', '/scenes/ep4-canteen-choice-b.jpg');
    this.load.image('ep4-canteen-choice-c', '/scenes/ep4-canteen-choice-c.jpg');

    // Aset khusus Episode 5: Sprite Kirana, Potret, Background & 5 Cutscene CG Layar Penuh
    this.load.image('kirana', '/characters/kirana.png?v=4');
    this.load.image('kirana-portrait', '/characters/kirana-portrait.png?v=4');
    this.load.image('episode-5-bg', '/scenes/episode-5-bg.jpg');
    this.load.image('episode5-bg', '/scenes/episode-5-bg.jpg');
    this.load.image('ep5-garden-bench-cg', '/scenes/ep5-garden-bench-cg.jpg');
    this.load.image('ep5-phone-threat-cg', '/scenes/ep5-phone-threat-cg.jpg');
    this.load.image('ep5-library-cg', '/scenes/ep5-library-cg.jpg');
    this.load.image('ep5-bk-room-cg', '/scenes/ep5-bk-room-cg.jpg');
    this.load.image('ep5-halte-cg', '/scenes/ep5-halte-cg.jpg');

    // Aset khusus Episode 6: Sprite Naya, Potret, Background & Cutscene CG Layar Penuh
    this.load.image('naya', '/characters/naya.png?v=4');
    this.load.image('naya-portrait', '/characters/naya-portrait.png?v=4');
    this.load.image('npc-naya-portrait', '/characters/naya-portrait.png?v=4');
    this.load.image('episode-6-bg', '/scenes/episode-6-bg.jpg?v=2');
    this.load.image('episode6-bg', '/scenes/episode-6-bg.jpg?v=2');
    this.load.image('ep6-corridor-chat-cg', '/scenes/ep6-corridor-chat-cg.jpg?v=3');
    this.load.image('ep6-gate-pressure-cg', '/scenes/ep6-gate-pressure-cg.jpg?v=3');
    this.load.image('ep6-safety-haven-cg', '/scenes/ep6-safety-haven-cg.jpg?v=3');
    this.load.image('ep6-teman-aman-cg', '/scenes/ep6-teman-aman-cg.jpg?v=3');

    // Aset Final Boss Battle Episode 6 & Standalone Runner
    this.load.image('boss-shadow', '/sprites/boss-shadow.png?v=5');
    this.load.image('boss-shadow-attack', '/sprites/boss-shadow-attack.png?v=2');
    this.load.image('boss-shadow-hurt', '/sprites/boss-shadow-hurt.png?v=2');
    this.load.image('boss-shadow-roar', '/sprites/boss-shadow-roar.png?v=4');
    this.load.image('boss-shadow-cast', '/sprites/boss-shadow-cast.png?v=4');
    this.load.image('boss-projectile', '/sprites/boss-projectile.png?v=2');
    this.load.image('shadow-spikes', '/sprites/shadow-spikes.png?v=2');
    this.load.image('shadow-meteor', '/sprites/shadow-meteor.png?v=2');
    this.load.image('courage-blast-surge', '/sprites/courage-blast-surge.png?v=1');
    this.load.image('courage-impact-burst', '/sprites/courage-impact-burst.png?v=1');
    this.load.image('courage-crest', '/sprites/courage-crest.png?v=1');
    this.load.image('runner-spikes', '/sprites/runner-spikes.png?v=2');
    this.load.image('runner-drone', '/sprites/runner-drone.png?v=2');
    this.load.image('runner-road', '/sprites/runner-road.jpg?v=2');

    // --- Potret NPC pendukung cerita (config/npcs.js) ---
    // Sama seperti background episode: kalau suatu episode belum punya
    // NPC terdaftar di sana, ya tidak ada apa pun yang di-load untuk
    // episode itu — aman, tidak menggagalkan loading keseluruhan.
    Object.values(NPCS).forEach((npc) => {
      if (npc.portraitKey && npc.portraitPath) {
        this.load.image(npc.portraitKey, npc.portraitPath);
      }
    });

    // Sprite karakter: setiap pose disimpan sebagai file gambar terpisah,
    // dikelompokkan per folder animasi (idle/, walk/), bukan satu
    // spritesheet gabungan. Supaya gampang diganti/ditambah pose satu-satu
    // tanpa perlu re-export spritesheet, dan gampang nambah folder baru
    // (mis. talk/, blink/) mengikuti pola yang sama nanti.
    this.load.image('player-idle', '/sprites/player/idle/idle.png');

    // Foto wajah untuk avatar HUD profil (pojok kiri atas) — OPSIONAL.
    // Belum ada asetnya di public/characters/ saat ini, jadi baris ini
    // akan memicu 'loaderror' yang diam-diam diabaikan (lihat handler
    // di atas) dan BasePlayerScene.createProfileHud() otomatis fallback
    // ke crop sprite 'player-idle'. Begitu file
    // public/characters/player-face.png ditaruh, HUD otomatis memakainya
    // tanpa perlu ubah kode apa pun lagi.
    this.load.image('player-face', '/characters/player-face.png');

    this.load.image('player-walk-1', '/sprites/player/walk/walk_1.png');
    this.load.image('player-walk-2', '/sprites/player/walk/walk_2.png');
    this.load.image('player-walk-3', '/sprites/player/walk/walk_3.png');
    this.load.image('player-walk-4', '/sprites/player/walk/walk_4.png');
    this.load.image('player-walk-5', '/sprites/player/walk/walk_5.png');

    this.load.image('player-run-1', '/sprites/player/run/run_1.png');
    this.load.image('player-run-2', '/sprites/player/run/run_2.png');
    this.load.image('player-run-3', '/sprites/player/run/run_3.png');
    this.load.image('player-run-4', '/sprites/player/run/run_4.png');

    this.load.image('player-jump-1', '/sprites/player/jump/jump_1.png');
    this.load.image('player-jump-2', '/sprites/player/jump/jump_2.png');
    this.load.image('player-jump-3', '/sprites/player/jump/jump_3.png');

    this.load.image('player-jump-run-1', '/sprites/player/jump_run/jump_run_1.png');
    this.load.image('player-jump-run-2', '/sprites/player/jump_run/jump_run_2.png');

    // Sprite Animasi Serangan Asertif Dara (Windup, Palm Strike, Energy Blast, Recovery)
    this.load.image('player-attack-1', '/sprites/player/attack/attack_1.png');
    this.load.image('player-attack-2', '/sprites/player/attack/attack_2.png');
    this.load.image('player-attack-3', '/sprites/player/attack/attack_3.png');
    this.load.image('player-attack-4', '/sprites/player/attack/attack_4.png');

    // Catatan: sound effect & BGM TIDAK di-load sebagai file di sini.
    // Sekarang dipakai AudioManager (src/features/game-engine/audio/AudioManager.js)
    // yang generate suara secara real-time via Web Audio API langsung
    // di browser, jadi tidak butuh file audio sama sekali.
  }

  async create() {
    // Animasi player dibuat SEKALI di sini, bukan di tiap scene episode
    // (lihat catatan lengkap di config/playerAnimations.js soal kenapa).
    createPlayerAnimations(this);

    // Pastikan font pixel (Jersey 15, Pixelify Sans) sudah dimuat browser
    // sebelum scene teks dibuat, supaya tidak fallback ke font default sesaat.
    try {
      await Promise.all([
        document.fonts.load('16px "Jersey 15"'),
        document.fonts.load('16px "Pixelify Sans"'),
      ]);
      await document.fonts.ready;
    } catch (e) {
      // Kalau gagal load (mis. offline), tetap lanjut dengan fallback monospace
      console.warn('Pixel font gagal dimuat, pakai fallback.', e);
    }

    let targetScene = this.game.registry.get('initialScene') || 'TitleScene';
    let targetData = this.game.registry.get('initialData') || {};
    if (targetScene === 'MiniBossScene' || targetScene === 'FinalBossScene') {
      targetScene = 'RunnerScene';
      targetData = { episodeId: 6, isLastEpisode: true, mode: 'runner', ...targetData };
    }
    this.scene.start(targetScene, targetData);
  }
}
