'use client';

import { useEffect, useRef } from 'react';
import BootScene from './scenes/BootScene';
import TitleScene from './scenes/TitleScene';
import MenuScene from './scenes/MenuScene';
import SettingsScene from './scenes/SettingsScene';
import EpisodeSelectScene from './scenes/EpisodeSelectScene';
import EpisodeIntroScene from './scenes/EpisodeIntroScene';
import EpisodeEndingScene from './scenes/EpisodeEndingScene';
import GameIntroGuideScene from './scenes/GameIntroGuideScene';
import Episode1Scene from './scenes/Episode1Scene';
import Episode2Scene from './scenes/Episode2Scene';
import Episode3Scene from './scenes/Episode3Scene';
import Episode4Scene from './scenes/Episode4Scene';
import Episode5Scene from './scenes/Episode5Scene';
import Episode6Scene from './scenes/Episode6Scene';
import RunnerScene from './scenes/RunnerScene';
import StoryEpisodeScene from './scenes/StoryEpisodeScene';
import { WORLD_WIDTH, WORLD_HEIGHT } from './config/gameConfig';
import { tryLockCurrentOrientation } from './utils/fullscreen';

/**
 * Minta browser masuk fullscreen pada interaksi pertama pengguna
 * (klik/tap/keypress) — TitleScene sudah menampilkan "PRESS SPACE TO
 * START" sebagai ajakan tap pertama itu, jadi TIDAK perlu overlay HTML
 * terpisah lagi di sini (sempat ditambahkan lalu dihapus lagi karena
 * jadi dobel dengan layar mulai yang sudah ada).
 * Fullscreen API WAJIB dipanggil dari user gesture, jadi tidak bisa
 * otomatis saat reload — harus menunggu satu interaksi.
 */
function setupAutoFullscreen() {
  const requestFS = () => {
    const el = document.documentElement;
    if (document.fullscreenElement) return; // sudah fullscreen
    const req =
      el.requestFullscreen ??
      el.webkitRequestFullscreen ??
      el.msRequestFullscreen;
    if (req) {
      req
        .call(el)
        .then(() => {
          // Sekalian coba kunci ke orientasi yang sedang dipakai saat
          // ini, supaya tidak berubah-ubah di tengah sesi. Gagal diam-
          // diam di platform yang tidak mendukung (termasuk iOS Safari
          // — di sana requestFullscreen sendiri juga tidak akan
          // pernah berhasil, itu keterbatasan WebKit, bukan bug kode).
          tryLockCurrentOrientation();
        })
        .catch(() => {
          // Browser menolak — abaikan saja, game tetap jalan.
        });
    }
    // Hapus semua listener setelah percobaan pertama, berhasil maupun
    // gagal, supaya tidak spam request setiap klik.
    window.removeEventListener('pointerdown', requestFS, true);
    window.removeEventListener('keydown', requestFS, true);
  };

  // `capture: true` supaya tertangkap lebih awal sebelum Phaser.
  window.addEventListener('pointerdown', requestFS, true);
  window.addEventListener('keydown', requestFS, true);

  // Kembalikan fungsi cleanup untuk useEffect.
  return () => {
    window.removeEventListener('pointerdown', requestFS, true);
    window.removeEventListener('keydown', requestFS, true);
  };
}

export default function PhaserGame({ initialScene, initialData }) {
  const gameRef = useRef(null);
  const phaserInstance = useRef(null);

  useEffect(() => {
    // Phaser mengakses `window`, jadi wajib di-load secara dinamis
    // di sisi client saja (tidak boleh di-import biasa di top-level).
    let destroyed = false;

    // Deteksi scene awal dari prop atau URL query string (mis. /game?mode=boss atau /game?scene=RunnerScene)
    let resolvedScene = initialScene;
    let resolvedData = initialData;
    if (resolvedScene === 'FinalBossScene' || resolvedScene === 'MiniBossScene') {
      resolvedScene = 'RunnerScene';
      resolvedData = { episodeId: 6, isLastEpisode: true, mode: 'runner' };
    }
    if (!resolvedScene && typeof window !== 'undefined') {
      try {
        const params = new URLSearchParams(window.location.search);
        const mode = params.get('mode') || params.get('scene');
        if (mode === 'boss' || mode === 'FinalBossScene' || mode === 'miniboss' || mode === 'MiniBossScene' || mode === 'runner' || mode === 'dino' || mode === 'RunnerScene') {
          resolvedScene = 'RunnerScene';
          resolvedData = { episodeId: 6, isLastEpisode: true, mode: 'runner' };
        } else if (mode) {
          resolvedScene = mode;
        }
      } catch (e) {
        // Abaikan jika query string gagal di-parse
      }
    }

    // Pasang auto-fullscreen listener — akan hilang sendiri setelah
    // interaksi pertama pengguna (klik/tap/tekan tombol).
    const cleanupFS = setupAutoFullscreen();

    import('phaser').then((PhaserModule) => {
      if (destroyed || phaserInstance.current) return;

      const Phaser = PhaserModule.default ?? PhaserModule;

      const config = {
        type: Phaser.AUTO,
        parent: gameRef.current,
        scene: [
          BootScene,
          TitleScene,
          MenuScene,
          SettingsScene,
          EpisodeSelectScene,
          EpisodeIntroScene,
          EpisodeEndingScene,
          GameIntroGuideScene,
          Episode1Scene,
          Episode2Scene,
          Episode3Scene,
          Episode4Scene,
          Episode5Scene,
          Episode6Scene,
          RunnerScene,
          StoryEpisodeScene,
        ],
        audio: {
          noAudio: true,
        },
        physics: {
          default: 'arcade',
          arcade: { gravity: { x: 0, y: 0 }, debug: false },
        },
        input: {
          // Default Phaser cuma lacak 1 pointer aktif -> tombol kiri/kanan
          // + jump tidak bisa ditekan bersamaan di HP. Dinaikkan supaya
          // beberapa jari bisa terdeteksi sekaligus (arah + run + jump).
          activePointers: 4,
        },
        scale: {
          mode: Phaser.Scale.ENVELOP,
          parent: gameRef.current,
          width: WORLD_WIDTH,
          height: WORLD_HEIGHT,
          autoCenter: Phaser.Scale.CENTER_BOTH,
        },
      };

      phaserInstance.current = new Phaser.Game(config);

      if (resolvedScene) {
        phaserInstance.current.registry.set('initialScene', resolvedScene);
        phaserInstance.current.registry.set('initialData', resolvedData || { episodeId: 6, isLastEpisode: true });
      }

      // Phaser Scale Manager sudah dengar event `resize` window, tapi di
      // iOS Safari event itu kadang tidak terpicu tepat waktu saat rotasi
      // layar atau saat address bar muncul/hilang (karena viewport CSS
      // berubah via `visualViewport`, bukan lewat `resize` biasa). Kalau
      // ini tidak ditangani, canvas bisa "nyangkut" di ukuran lama —
      // itulah sumber tampilan tidak konsisten saat ganti orientasi.
      //
      // Solusi: paksa Phaser hitung ulang ukuran (`scale.refresh()`) pada
      // beberapa event tambahan, plus retry singkat setelah rotasi karena
      // beberapa browser mengubah `innerWidth/innerHeight` dengan delay
      // beberapa ratus ms setelah event `orientationchange` ditembakkan.
      const forceRefresh = () => {
        if (!phaserInstance.current) return;
        phaserInstance.current.scale.refresh();
      };

      const onOrientationChange = () => {
        forceRefresh();
        // Retry berkala menangkap kasus browser yang telat update
        // innerWidth/innerHeight setelah rotasi selesai secara visual.
        [50, 150, 300, 600].forEach((delay) => setTimeout(forceRefresh, delay));
      };

      window.addEventListener('orientationchange', onOrientationChange);
      window.addEventListener('resize', forceRefresh);
      if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', forceRefresh);
        window.visualViewport.addEventListener('scroll', forceRefresh);
      }

      phaserInstance.current.__cleanupResizeListeners = () => {
        window.removeEventListener('orientationchange', onOrientationChange);
        window.removeEventListener('resize', forceRefresh);
        if (window.visualViewport) {
          window.visualViewport.removeEventListener('resize', forceRefresh);
          window.visualViewport.removeEventListener('scroll', forceRefresh);
        }
      };
    });

    return () => {
      destroyed = true;
      cleanupFS();
      if (phaserInstance.current) {
        try {
          phaserInstance.current.__cleanupResizeListeners?.();
          phaserInstance.current.destroy(true);
        } catch (e) {
          console.warn('[PhaserGame] Error destroying Phaser instance:', e);
        } finally {
          phaserInstance.current = null;
        }
      }
    };
  }, []);

  return <div ref={gameRef} id="game-container" />;
}
